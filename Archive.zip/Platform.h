//
// Created by Kathleen Nguyen on 11/14/21.
//

#ifndef CATCHASE_PLATFORM_H
#define CATCHASE_PLATFORM_H
#include <SFML/Graphics.hpp>
#include "Files.h"
class Platform : public sf::Sprite
{
public:
    Platform();
};


#endif //CATCHASE_PLATFORM_H
