//
// Created by Kathleen Nguyen on 11/20/21.
//

#ifndef CATCHASE_RED_MUSHROOM_H
#define CATCHASE_RED_MUSHROOM_H
#include "FallingObject.h"

class Red_Mushroom : public FallingObject
{
public:
    Red_Mushroom();
};


#endif //CATCHASE_RED_MUSHROOM_H
