#include "CatchGame.h"

////How to play
//Use A and D or Left and Right arrow keys to move left and right.
//Use the space bar to jump.
//Use Q to activate power ups.

int main()
{
    CatchGame game;
    game.run();
    return 0;
}