//
// Created by Kathleen Nguyen on 11/27/21.
//

#ifndef CATCHASE_OBJECTCATEGORY_H
#define CATCHASE_OBJECTCATEGORY_H
enum ObjectCategory
{
    POINTS, POWER_UP
};
#endif //CATCHASE_OBJECTCATEGORY_H
