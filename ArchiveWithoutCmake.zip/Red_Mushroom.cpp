//
// Created by Kathleen Nguyen on 11/20/21.
//

#include "Red_Mushroom.h"
Red_Mushroom::Red_Mushroom() : FallingObject(RED_MUSHROOM)
{
    setPoints(100);
    setCategory(POINTS);
}
