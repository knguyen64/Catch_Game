//
// Created by Kathleen Nguyen on 11/29/21.
//

#include "Green_Mushroom.h"
Green_Mushroom::Green_Mushroom() : FallingObject(GREEN_MUSHROOM)
{
    setPoints(300);
    setCategory(POINTS);
}
