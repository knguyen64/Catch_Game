//
// Created by Kathleen Nguyen on 11/20/21.
//

#include "Poison_Mushroom.h"

Poison_Mushroom::Poison_Mushroom() : FallingObject(POISON_MUSHROOM)
{
    setCategory(POINTS);
}
