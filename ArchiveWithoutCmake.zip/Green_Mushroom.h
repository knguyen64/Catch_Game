//
// Created by Kathleen Nguyen on 11/29/21.
//

#ifndef CATCHASE_GREEN_MUSHROOM_H
#define CATCHASE_GREEN_MUSHROOM_H
#include "FallingObject.h"
#include <iostream>

class Green_Mushroom : public FallingObject
{
public:
    Green_Mushroom();
};


#endif //CATCHASE_GREEN_MUSHROOM_H
