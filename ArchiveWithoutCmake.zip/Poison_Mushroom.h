//
// Created by Kathleen Nguyen on 11/20/21.
//

#ifndef CATCHASE_POISON_MUSHROOM_H
#define CATCHASE_POISON_MUSHROOM_H
#include "FallingObject.h"

class Poison_Mushroom : public FallingObject
{
public:
    Poison_Mushroom();
};


#endif //CATCHASE_POISON_MUSHROOM_H
